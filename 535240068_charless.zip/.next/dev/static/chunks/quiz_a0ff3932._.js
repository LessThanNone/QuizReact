(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d034cc5d._.js",
  "static/chunks/2570e_next_dist_compiled_react-dom_54a576a1._.js",
  "static/chunks/2570e_next_dist_compiled_react-server-dom-turbopack_cbd83153._.js",
  "static/chunks/2570e_next_dist_compiled_next-devtools_index_2306ef1f.js",
  "static/chunks/2570e_next_dist_compiled_47feac4b._.js",
  "static/chunks/2570e_next_dist_client_325deca5._.js",
  "static/chunks/2570e_next_dist_7b887314._.js",
  "static/chunks/2570e_@swc_helpers_cjs_3a6cca50._.js"
],
    source: "entry"
});
