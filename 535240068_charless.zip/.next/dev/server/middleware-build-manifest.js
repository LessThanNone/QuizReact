globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/2570e_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d034cc5d._.js",
    "static/chunks/2570e_next_dist_compiled_react-dom_54a576a1._.js",
    "static/chunks/2570e_next_dist_compiled_react-server-dom-turbopack_cbd83153._.js",
    "static/chunks/2570e_next_dist_compiled_next-devtools_index_2306ef1f.js",
    "static/chunks/2570e_next_dist_compiled_47feac4b._.js",
    "static/chunks/2570e_next_dist_client_325deca5._.js",
    "static/chunks/2570e_next_dist_7b887314._.js",
    "static/chunks/2570e_@swc_helpers_cjs_3a6cca50._.js",
    "static/chunks/quiz_a0ff3932._.js",
    "static/chunks/turbopack-quiz_2eea8cf5._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];