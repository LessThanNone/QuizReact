module.exports = [
"[project]/quiz/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz__next-internal_server_app__not-found_page_actions_4b2946f6.js.map