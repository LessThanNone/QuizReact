module.exports = [
"[project]/quiz/.next-internal/server/app/kopi/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz__next-internal_server_app_kopi_page_actions_88c437d7.js.map