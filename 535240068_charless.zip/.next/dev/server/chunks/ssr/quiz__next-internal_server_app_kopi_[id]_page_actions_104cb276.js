module.exports = [
"[project]/quiz/.next-internal/server/app/kopi/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz__next-internal_server_app_kopi_%5Bid%5D_page_actions_104cb276.js.map