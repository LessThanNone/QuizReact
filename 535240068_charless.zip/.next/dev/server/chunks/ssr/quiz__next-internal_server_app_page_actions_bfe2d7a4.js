module.exports = [
"[project]/quiz/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=quiz__next-internal_server_app_page_actions_bfe2d7a4.js.map